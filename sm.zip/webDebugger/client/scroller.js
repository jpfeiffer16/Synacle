$.fn.scroller = function() {
  const $this = $(this);

  
}