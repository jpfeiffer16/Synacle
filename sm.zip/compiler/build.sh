node compiler.js -p testexpression.bc
node ../vm.js -b ../compiler/testexpression.bin

