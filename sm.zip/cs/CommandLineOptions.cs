using System;
using CommandLine;

public class CommandLineOptions {
  [Option('i', "information", Default = false, HelpText = "Log information about the program to be run")]
  public bool Information { get; set; }

  [Option('b', "binary", Default = "../challenge.bin", HelpText = "Binary path")]
  public string Binary { get; set; }
}